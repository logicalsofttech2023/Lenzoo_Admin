import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faLock,
  faEnvelope,
  faPhone,
  faMapMarkerAlt,
  faSave,
  faKey,
  faUpload,
  faUserCog,
  faEdit,
} from "@fortawesome/free-solid-svg-icons";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
const Profile = () => {
  const [activeTab, setActiveTab] = useState("profile");
  const [userData, setUserData] = useState({});
  const [profiledetail, setProfiledetail] = useState({});

  const [passwordData, setPasswordData] = useState({
    Admin_Password: "",
    newPassword: "",
  });

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  let adminId = localStorage.getItem("adminid");

  useEffect(() => {
    FeatchProfile();
  }, [adminId]);

  const FeatchProfile = () => {
    const data = {
      Admin_Id: adminId,
    };
    axios
      .post(`${import.meta.env.VITE_API_BASE_URL}api/admin/admin_profile`, data)
      .then((result) => {
        let res = result?.data?.data;
        setUserData(res);
        setProfiledetail(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData((prev) => ({ ...prev, [name]: value }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast.error("Image size should be less than 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
        setUserData((prev) => ({ ...prev, image: file }));
        toast.success("Image selected successfully!");
      };
      reader.readAsDataURL(file);
    }
  };
  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const formData = new FormData();
      formData.append("adminId", adminId);
      formData.append("first_name", userData.first_name);
      formData.append("last_name", userData.last_name);
      formData.append("phone", userData.phone);
      formData.append("address", userData.address);
      formData.append("city", userData.city);
      if (userData.image instanceof File) {
        formData.append("image", userData.image);
      }

      const response = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL}api/admin/update_admin_profile`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      toast.success("Profile updated successfully!");
      setIsEditing(false);

      // Update the image preview with the new image URL if available in response
      if (response.data?.image) {
        setUserData((prev) => ({ ...prev, image: response.data.image }));
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update profile");
    } finally {
      setIsLoading(false);
    }
  };
  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    const data = {
      Admin_Id: adminId,
      oldPassword: passwordData.Admin_Password,
      newPassword: passwordData.newPassword,
    };

    setIsLoading(true);
    axios
      .post(
        `${import.meta.env.VITE_API_BASE_URL}api/admin/change_pass_admin`,
        data
      )
      .then(() => {
        toast.success("Password changed successfully!");
        setPasswordData({
          Admin_Password: "",
          newPassword: "",
        });
      })
      .catch((error) => {
        toast.error(error.response?.data?.message || "Error changing password");
      })
      .finally(() => {
        setIsLoading(false);
      });
  };
  return (
    <div className="-mt-18 container-fluid py-4 bg-light">
      <ToastContainer position="top-right" autoClose={3000} />
      <div className="row">
        <div className="col-lg-4">
          <div className="card mb-4 shadow-sm border-0">
            <div className="card-body text-center p-4">
              <div className="position-relative d-inline-block mb-3">
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    className="rounded-circle border border-4 border-white shadow"
                    width="150"
                    height="150"
                    alt="Profile"
                  />
                ) : userData.image ? (
                  <img
                    src={`${import.meta.env.VITE_API_BASE_URL}uploads/admin/${
                      userData.image
                    }`}
                    className="rounded-circle border border-4 border-white shadow"
                    width="150"
                    height="150"
                    alt="Profile"
                  />
                ) : (
                  <div
                    className="rounded-circle border border-4 border-white shadow bg-light d-flex align-items-center justify-content-center"
                    style={{ width: "150px", height: "150px" }}>
                    <i className="bi bi-person fs-1 text-muted"></i>
                  </div>
                )}

                <label
                  htmlFor="profileImageUpload"
                  className="position-absolute bottom-0 end-0 bg-primary text-white rounded-circle p-2 shadow-sm cursor-pointer"
                  style={{ width: "40px", height: "40px" }}>
                  <FontAwesomeIcon icon={faEdit} />
                  <input
                    type="file"
                    id="profileImageUpload"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="d-none"
                  />
                </label>
              </div>
              <h4 className="mb-1 fw-bold">{`${profiledetail.first_name} ${profiledetail.last_name}`}</h4>
              <p className="text-muted mb-2">{profiledetail.Admin_Email}</p>
              <p className="text-muted mb-3">{profiledetail.bio}</p>
              <span className="badge bg-primary bg-opacity-10 text-primary fs-14 mb-3">
                <FontAwesomeIcon icon={faUserCog} className="me-1" />
                Admin
              </span>
            </div>
          </div>

          <div className="card shadow-sm border-0">
            <div className="card-body p-4">
              <h5 className="card-title mb-3 fw-bold">Contact Information</h5>
              <ul className="list-unstyled mb-0">
                <li className="mb-3 d-flex align-items-center">
                  <div className="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3">
                    <FontAwesomeIcon icon={faEnvelope} />
                  </div>
                  <div>
                    <small className="text-muted">Email</small>
                    <p className="mb-0">{profiledetail.Admin_Email}</p>
                  </div>
                </li>
                <li className="mb-3 d-flex align-items-center">
                  <div className="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3">
                    <FontAwesomeIcon icon={faPhone} />
                  </div>
                  <div>
                    <small className="text-muted">Phone</small>
                    <p className="mb-0">{profiledetail.phone}</p>
                  </div>
                </li>
                <li className="d-flex align-items-center">
                  <div className="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3">
                    <FontAwesomeIcon icon={faMapMarkerAlt} />
                  </div>
                  <div>
                    <small className="text-muted">Address</small>
                    <p className="mb-0">{profiledetail.address}</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="col-lg-8">
          <div className="card shadow-sm border-0">
            <div className="card-body p-4">
              <ul
                className="nav nav-tabs nav-tabs-custom mb-4"
                id="profile-tabs">
                <li className="nav-item">
                  <button
                    className={`nav-link ${
                      activeTab === "profile" ? "active" : ""
                    }`}
                    onClick={() => setActiveTab("profile")}>
                    <FontAwesomeIcon icon={faUser} className="me-2" />
                    Profile
                  </button>
                </li>
                <li className="nav-item">
                  <button
                    className={`nav-link ${
                      activeTab === "password" ? "active" : ""
                    }`}
                    onClick={() => setActiveTab("password")}>
                    <FontAwesomeIcon icon={faKey} className="me-2" />
                    Password
                  </button>
                </li>
              </ul>

              {activeTab === "profile" && (
                <form onSubmit={handleProfileSubmit}>
                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="firstName" className="form-label">
                        First Name
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.first_name ? "is-invalid" : ""
                        }`}
                        id="firstName"
                        name="first_name"
                        value={userData.first_name}
                        onChange={handleInputChange}
                        // disabled={!isEditing}
                      />
                    </div>

                    <div className="col-md-6 mb-3">
                      <label htmlFor="lastName" className="form-label">
                        Last Name
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.last_name ? "is-invalid" : ""
                        }`}
                        id="lastName"
                        name="last_name"
                        value={userData.last_name}
                        onChange={handleInputChange}
                        // disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="phone" className="form-label">
                        Phone
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.phone ? "is-invalid" : ""
                        }`}
                        id="phone"
                        name="phone"
                        value={userData.phone}
                        onChange={handleInputChange}
                        // disabled={!isEditing}
                      />
                    </div>

                    <div className="col-md-6 mb-3">
                      <label htmlFor="address" className="form-label">
                        Address
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.address ? "is-invalid" : ""
                        }`}
                        id="address"
                        name="address"
                        value={userData.address}
                        onChange={handleInputChange}
                        // disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="row mb-3">
                    <div className="col-md-6 mb-3">
                      <label htmlFor="city" className="form-label">
                        City
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.city ? "is-invalid" : ""
                        }`}
                        id="city"
                        name="city"
                        value={userData.city}
                        onChange={handleInputChange}
                        // disabled={!isEditing}
                      />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label htmlFor="city" className="form-label">
                        Email
                      </label>
                      <input
                        type="text"
                        className={`form-control ${
                          errors.Admin_Email ? "is-invalid" : ""
                        }`}
                        id="city"
                        name="Admin_Email"
                        value={userData.Admin_Email}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>

                  <div className="d-flex justify-content-end gap-2">
                    {!isEditing ? (
                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={() => setIsEditing(true)}>
                        <FontAwesomeIcon icon={faEdit} className="me-2" />
                        Edit Profile
                      </button>
                    ) : (
                      <>
                        <button
                          type="button"
                          className="btn btn-outline-secondary"
                          onClick={() => {
                            setIsEditing(false);
                            setImagePreview(null);
                          }}>
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary"
                          disabled={isLoading}>
                          {isLoading ? (
                            <>
                              <span className="spinner-border spinner-border-sm me-2"></span>
                              Saving...
                            </>
                          ) : (
                            <>
                              <FontAwesomeIcon icon={faSave} className="me-2" />
                              Save Changes
                            </>
                          )}
                        </button>
                      </>
                    )}
                  </div>
                </form>
              )}

              {activeTab === "password" && (
                <form onSubmit={handlePasswordSubmit}>
                  <div className="mb-3">
                    <label htmlFor="formCurrentPassword" className="form-label">
                      Current Password
                    </label>
                    <div className="input-group">
                      <input
                        type={showCurrentPassword ? "text" : "password"}
                        className={`form-control ${
                          errors.Admin_Password ? "is-invalid" : ""
                        }`}
                        id="formCurrentPassword"
                        name="Admin_Password"
                        value={passwordData.Admin_Password}
                        onChange={handlePasswordChange}
                        placeholder="Enter current password"
                      />
                      <button
                        type="button"
                        className="btn btn-outline-primary"
                        onClick={() =>
                          setShowCurrentPassword(!showCurrentPassword)
                        }>
                        <FontAwesomeIcon
                          icon={showCurrentPassword ? faEyeSlash : faEye}
                        />
                      </button>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="formNewPassword" className="form-label">
                      New Password
                    </label>
                    <div className="input-group">
                      <input
                        type={showNewPassword ? "text" : "password"}
                        className={`form-control ${
                          errors.newPassword ? "is-invalid" : ""
                        }`}
                        id="formNewPassword"
                        name="newPassword"
                        value={passwordData.newPassword}
                        onChange={handlePasswordChange}
                        placeholder="Enter new password"
                      />
                      <button
                        type="button"
                        className="btn btn-outline-primary"
                        onClick={() => setShowNewPassword(!showNewPassword)}>
                        <FontAwesomeIcon
                          icon={showNewPassword ? faEyeSlash : faEye}
                        />
                      </button>
                    </div>
                  </div>

                  <div className="alert alert-info mb-4">
                    <strong>Password requirements:</strong>
                    <ul className="mb-0">
                      <li>Minimum 8 characters</li>
                      <li>At least one uppercase letter</li>
                      <li>At least one number</li>
                      <li>At least one special character</li>
                    </ul>
                  </div>

                  <div className="d-flex justify-content-end">
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={isLoading}>
                      {isLoading ? (
                        "Updating..."
                      ) : (
                        <>
                          <FontAwesomeIcon icon={faKey} className="me-2" />
                          Change Password
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
